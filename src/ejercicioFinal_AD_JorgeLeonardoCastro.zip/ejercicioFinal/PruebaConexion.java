package ejercicioFinal;

public class PruebaConexion {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ConexionZapatos.conectar();
	}

}
